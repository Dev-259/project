<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Management System</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            text-align: center;
            color: white;
            overflow: hidden;
            background: linear-gradient(to right, #ff7e5f, #feb47b);
        }

        .background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background-size: cover;
            background-position: center;
        }
        
        .bg1, .bg2 {
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('assets/bg3.jpg') no-repeat center center/cover;
            animation: fade1 10s infinite alternate;
        }
        .bg2 {
            background: url('assets/bg6.jpg') no-repeat center center/cover;
            animation: fade2 10s infinite alternate;
        }

        @keyframes fade1 {
            0% { opacity: 1; }
            50% { opacity: 0.6; }
            100% { opacity: 1; }
        }

        @keyframes fade2 {
            0% { opacity: 0.6; }
            50% { opacity: 1; }
            100% { opacity: 0.6; }
        }

        .overlay {
            background: rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .container {
            position: relative;
            z-index: 2;
            padding: 100px 20px;
            animation: slideIn 1.5s ease-in-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h1 {
            color: #fff;
            font-size: 50px;
            margin-bottom: 30px;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.8);
            font-weight: 600;
            animation: fadeInText 3s ease-in-out;
        }

        @keyframes fadeInText {
            0% { opacity: 0; transform: translateY(50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        p {
            font-size: 20px;
            max-width: 800px;
            margin: auto;
            line-height: 1.6;
            font-weight: 300;
            color: #fff;
            text-shadow: 1px 1px 4px rgba(0,0,0,0.5);
            animation: fadeInText 4s ease-in-out;
        }

        .buttons {
            margin-top: 40px;
        }

        .btn {
            display: inline-block;
            padding: 15px 35px;
            font-size: 18px;
            margin: 15px;
            color: white;
            background: linear-gradient(90deg, #ff7e5f, #feb47b);
            border: none;
            border-radius: 5px;
            cursor: pointer;
            position: relative;
            transition: 0.3s;
            text-decoration: none;
            animation: buttonFade 2s ease-in-out;
        }

        @keyframes buttonFade {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .btn i {
            margin-right: 10px;
        }

        .btn:hover {
            background: linear-gradient(90deg, #feb47b, #ff7e5f);
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(255, 87, 34, 0.6);
        }

        .btn:active {
            transform: scale(1);
        }

        .btn .fa {
            font-size: 20px;
        }

    </style>
</head>
<body>
    <div class="background">
        <div class="bg1"></div>
        <div class="bg2"></div>
    </div>
    <div class="overlay"></div>
    <div class="container">
        <h1>Welcome to the Blood Bank System</h1>
        <p>
            Our Blood Bank helps you donate blood or request blood when you need it. It's easy and safe to donate, and it helps save lives.
            You can be a hero by donating blood or requesting it for someone in need.
        </p>
        <div class="buttons">
            <a href="auth/admin_login.php" class="btn">
                <i class="fas fa-user-shield"></i> Admin Login
            </a>
            <a href="auth/user_login.php" class="btn">
                <i class="fas fa-users"></i> User Login
            </a>
        </div>
    </div>
</body>
</html>
