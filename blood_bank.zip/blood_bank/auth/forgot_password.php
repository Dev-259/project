<?php
// Include the database connection file
include('../db_connect.php');

session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if passwords match
    if ($new_password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Check if email exists
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Update password
            $update_sql = "UPDATE users SET password = '$new_password' WHERE email = '$email'";
            if ($conn->query($update_sql) === TRUE) {
                // Redirect to login page after 3 seconds
                echo "<script>
                        alert('Password updated successfully! Redirecting to login page...');
                        window.location.href = 'user_login.php';
                      </script>";
                exit();
            } else {
                $error = "Error updating password!";
            }
        } else {
            $error = "Email not found!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Blood Bank Management System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            text-align: center;
            color: #fff;
            background: linear-gradient(to right, #1c1c1c, #333);
        }
        .container {
            margin-top: 100px;
        }
        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 10px;
            display: inline-block;
            width: 340px;
            box-sizing: border-box;
        }
        .form-container input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn {
            display: inline-block;
            padding: 15px 30px;
            font-size: 18px;
            margin-top: 10px;
            color: #fff;
            background: linear-gradient(to right, #ff7e5f, #feb47b);
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background: linear-gradient(to right, #feb47b, #ff7e5f);
        }
        .error {
            color: #ff4040;
            font-weight: bold;
        }
        .success {
            color: #28a745;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Forgot Password</h1>

        <?php if (isset($error)) { ?>
            <div class="error"><?php echo $error; ?></div>
        <?php } ?>

        <div class="form-container">
            <form action="forgot_password.php" method="POST">
                <input type="email" name="email" placeholder="Enter your email" required>
                <input type="password" name="new_password" placeholder="New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <button type="submit" class="btn">Reset Password</button>
            </form>
        </div>
    </div>
</body>
</html>
