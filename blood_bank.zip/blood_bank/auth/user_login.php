<?php
// Include the database connection file
include('../db_connect.php');

session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the email and password match in the database
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    // Check if the query returns a row (successful login)
    if ($result->num_rows > 0) {
        // User login successful, start a session
        $_SESSION['user_logged_in'] = true;
        $_SESSION['user_email'] = $email;

        // Redirect to the desired page after successful login (e.g., home.php)
        header("Location: ../user/home.php");  // Update this to your page
        exit();
    } else {
        // Login failed, display an error message
        $error = "Invalid email or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login - Blood Bank Management System</title>
    <!-- Include Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Add your existing CSS styles here */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            text-align: center;
            color: #fff;
            overflow: hidden;
            background: linear-gradient(to right, #1c1c1c, #333);
        }
        .background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }
        .bg1, .bg2 {
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('../assets/bg4.jpg') no-repeat center center/cover;
            animation: fade 10s infinite alternate;
        }
        @keyframes fade {
            0% { opacity: 0.8; }
            50% { opacity: 0.4; }
            100% { opacity: 0.8; }
        }
        .overlay {
            background: rgba(0, 0, 0, 0.7);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1; /* Ensure overlay is behind the back button */
        }
        .container {
            position: relative;
            z-index: 2;
            padding: 80px 20px;
            animation: slideIn 1.5s ease-in-out;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        h1 {
            color: #fff;
            font-size: 36px;
            margin-bottom: 20px;
            font-weight: 600;
            animation: fadeIn 2s ease-in-out;
        }
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 10px;
            display: inline-block;
            margin-top: 40px;
            width: 340px;
            box-sizing: border-box;
            animation: fadeInUp 1s ease-in-out;
        }
        @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .form-container input[type="email"], .form-container input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
            padding-left: 40px; /* Add space for icons */
            animation: slideIn 0.5s ease-out;
        }
        .form-container input[type="email"]::placeholder,
        .form-container input[type="password"]::placeholder {
            color: #888;
        }
        /* Icon style */
        .form-container input[type="email"]::before, .form-container input[type="password"]::before {
            position: absolute;
            top: 12px;
            left: 12px;
            color: #555;
            font-size: 18px;
        }
        .btn {
            display: inline-block;
            padding: 15px 30px;
            font-size: 18px;
            margin: 10px;
            color: #fff;
            background: linear-gradient(to right, #ff7e5f, #feb47b);
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s ease-in-out;
            position: relative;
            animation: buttonHover 0.4s ease-in-out infinite alternate;
        }
        @keyframes buttonHover {
            0% { transform: scale(1); }
            100% { transform: scale(1.05); }
        }
        .btn:hover {
            transform: scale(1.1);
            background: linear-gradient(to right, #feb47b, #ff7e5f);
        }
        .signup-message {
            color: #ff7e5f;  /* Color for the "Don't have an account?" message */
            font-size: 14px;
            margin-top: 10px;
        }
        .error {
            color: #ff4040;
            margin-top: 10px;
            font-weight: bold;
        }
        .forgot-password {
            margin-top: 10px;
            font-size: 14px;
        }
        .forgot-password a {
            color: #ff7e5f;
            text-decoration: none;
        }
        .forgot-password a:hover {
            text-decoration: underline;
        }
        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.5);
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s ease-in-out;
            z-index: 3; /* Ensure it's above the overlay */
        }
        .back-btn:hover {
            background: rgba(255, 255, 255, 0.8);
        }
        .back-btn i {
            font-size: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="background">
        <div class="bg1"></div>
        <div class="bg2"></div>
    </div>
    <div class="overlay"></div>
    
    <!-- Back button -->
    <button class="back-btn" onclick="window.location.href='../index.php'">
        <i class="fas fa-arrow-left"></i> Back
    </button>

    <div class="container">
        <h1>User Login</h1>

        <?php if (isset($error)) { ?>
            <div class="error"><?php echo $error; ?></div>
        <?php } ?>

        <div class="form-container">
            <form action="user_login.php" method="POST">
                <!-- Email input with icon -->
                <div style="position: relative;">
                    <i class="fas fa-envelope" style="position: absolute; top: 12px; left: 12px; color: #888;"></i>
                    <input type="email" name="email" placeholder="Email" required><br>
                </div>

                <!-- Password input with icon -->
                <div style="position: relative;">
                    <i class="fas fa-lock" style="position: absolute; top: 12px; left: 12px; color: #888;"></i>
                    <input type="password" name="password" placeholder="Password" required><br>
                </div>

                <!-- Login button -->
                <button type="submit" class="btn">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>

            <!-- Forgot Password link -->
            <div class="forgot-password">
                <p><a href="forgot_password.php">Forgot Password?</a></p>
            </div>
            
            <!-- Sign Up message -->
            <div class="signup-message">
                <p>Don't have an account? <a href="user_signup.php">Sign Up</a></p>
            </div>
        </div>
    </div>
</body>
</html>
