<?php
// Include database connection
include('../db_connect.php');

// Fetch blood availability from the blood_stock table
$query = "SELECT * FROM blood_stock";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Availability</title>
    <!-- Font Awesome Link for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        /* Background Image */
        body {
            background-image: url('../assets/bg3.jpg');
            background-size: cover;
            background-position: center;
            font-family: 'Arial', sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            animation: fadeInBackground 2s ease-in-out;
        }

        /* Page Fade-in Effect */
        @keyframes fadeInBackground {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        /* Back to Dashboard Icon */
        .back-to-dashboard {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 1.5em;
            color: #ffcc00;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 10px;
            border-radius: 50%;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .back-to-dashboard:hover {
            transform: scale(1.1);
            background-color: rgba(0, 0, 0, 0.7);
        }

        /* Container */
        .container {
            width: 80%;
            margin: 100px auto;
            padding: 30px;
            background: rgba(0, 0, 0, 0.6); /* Semi-transparent background */
            border-radius: 15px;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.3);
            animation: slideIn 2s ease-in-out;
        }

        /* Heading */
        h2 {
            text-align: center;
            font-size: 2.5em;
            margin-bottom: 20px;
            text-transform: uppercase;
            color: #ffcc00;
            font-weight: bold;
            letter-spacing: 2px;
            animation: slideInLeft 1.5s ease-out;
        }

        /* Card Layout for Blood Availability */
        .card-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }

        .card {
            background-color: rgba(0, 0, 0, 0.8);
            border-radius: 15px;
            padding: 20px;
            width: 250px;
            text-align: center;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
        }

        .card h3 {
            font-size: 1.8em;
            color: #ffcc00;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .card p {
            font-size: 1.2em;
            margin: 5px 0;
        }

        .card .status {
            font-size: 1.4em;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            text-transform: uppercase;
        }

        .available {
            color: #4CAF50;
            background-color: rgba(76, 175, 80, 0.2);
        }

        .out-of-stock {
            color: #F44336;
            background-color: rgba(244, 67, 54, 0.2);
        }

        .low-stock {
            color: #FF9800;
            background-color: rgba(255, 152, 0, 0.2);
        }

        /* Animation Effects */
        @keyframes slideInLeft {
            0% {
                transform: translateX(-100%);
            }
            100% {
                transform: translateX(0);
            }
        }

    </style>
</head>
<body>

<!-- Back to Dashboard Icon -->
<a href="home.php" class="back-to-dashboard">
    <i class="fas fa-arrow-left"></i> <!-- Back arrow icon from Font Awesome -->
</a>

<div class="container">
    <h2>Blood Availability</h2>
    <div class="card-container">
        <?php
        // Fetch and display blood stock details
        while ($row = mysqli_fetch_assoc($result)) {
            $statusClass = '';
            $statusText = '';
            if ($row['quantity'] > 5) {
                $statusClass = "available";
                $statusText = "Available";
            } elseif ($row['quantity'] > 0) {
                $statusClass = "low-stock";
                $statusText = "Low Stock";
            } else {
                $statusClass = "out-of-stock";
                $statusText = "Out of Stock";
            }
            echo "<div class='card'>
                    <h3>{$row['blood_group']}</h3>
                    <p>Quantity: {$row['quantity']} units</p>
                    <p class='status $statusClass'>$statusText</p>
                  </div>";
        }
        ?>
    </div>
</div>

</body>
</html>
