<?php
// Include the database connection and start the session
include('../db_connect.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: ../auth/user_login.php");
    exit();
}

// Get the user email from the session
$email = $_SESSION['user_email'];

// Retrieve user details from the database
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// If user exists
if ($user) {
    $name = $user['name'];
    $blood_group = $user['blood_group'];
} else {
    // Redirect to login page if user not found
    header("Location: ../user/user_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome - Blood Bank Management System</title>
  <!-- Font Awesome CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-attachment: fixed;
      background-position: center;
      background-size: cover;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      height: 100vh;
      position: relative;
      overflow-x: hidden;
      overflow-y: auto;
    }

    /* Background image */
    .background-image {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      background-image: url('../assets/bg3.jpg'); /* Replace with your image path */
      background-position: center;
      background-size: cover;
      background-repeat: no-repeat;
      opacity: 0.7;
      animation: fadeIn 3s forwards; /* Fade-in animation */
    }

    /* Menu Bar */
    .menu-bar {
      position: fixed;
      left: -250px;
      top: 0;
      width: 250px;
      height: 100vh;
      background: rgba(51, 51, 51, 0.9);
      padding-top: 60px;
      transition: left 0.3s ease-in-out;
      z-index: 9999;
    }

    .menu-bar a {
      display: flex;
      align-items: center;
      color: white;
      padding: 15px;
      text-decoration: none;
      font-size: 18px;
      transition: background-color 0.3s ease-in-out;
    }

    .menu-bar a i {
      margin-right: 10px;
    }

    .menu-bar a:hover {
      background: #575757;
    }

    .menu-toggle {
      position: fixed;
      left: 10px;
      top: 10px;
      background: #333;
      color: white;
      padding: 10px 15px;
      cursor: pointer;
      border-radius: 5px;
      z-index: 10000;
    }

    .menu-toggle:hover {
      background: #575757;
    }

    .close-menu {
      position: absolute;
      top: 10px;
      right: 15px;
      color: white;
      font-size: 20px;
      cursor: pointer;
    }

    /* Container */
    .container {
      width: 90%;
      max-width: 1000px;
      margin-top: 80px;
      text-align: center;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      padding: 30px;
    }

    .dashboard-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      justify-content: center;
      margin-top: 20px;
    }

    .box {
      background: linear-gradient(135deg, #007bff, #00c6ff);
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
      color: white;
      transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
      animation: boxFadeIn 1s ease-out;
    }

    @keyframes boxFadeIn {
      0% {
        opacity: 0;
        transform: translateY(20px);
      }
      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .box i {
      font-size: 40px;
      margin-bottom: 10px;
    }

    .box:hover {
      transform: scale(1.05);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    .box a {
      display: block;
      margin-top: 10px;
      color: white;
      font-weight: bold;
      text-decoration: none;
      background: rgba(255, 255, 255, 0.2);
      padding: 8px;
      border-radius: 5px;
      transition: background 0.3s ease-in-out;
    }

    .box a:hover {
      background: rgba(255, 255, 255, 0.4);
    }

    /* Logout button */
    .logout-btn {
      position: fixed;
      right: 20px;
      top: 20px;
      background: #dc3545;
      padding: 10px 20px;
      border-radius: 5px;
      color: white;
      text-decoration: none;
      display: flex;
      align-items: center;
      transition: background 0.3s ease-in-out;
    }

    .logout-btn i {
      margin-right: 8px;
    }

    .logout-btn:hover {
      background: #c82333;
    }
  </style>
</head>
<body>
  <!-- Background Image -->
  <div class="background-image"></div>

  <!-- Menu Toggle -->
  <div class="menu-toggle" onclick="toggleMenu()">☰ Menu</div>

  <!-- Menu Bar -->
  <div class="menu-bar" id="menuBar">
    <span class="close-menu" onclick="toggleMenu()">&times;</span>
    <a href="home.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="search_donors.php"><i class="fas fa-users"></i> Search Donors</a>
    <a href="request_blood.php"><i class="fas fa-hand-holding-heart"></i> Request Blood</a>
    <a href="blood_availability.php"><i class="fas fa-tint"></i> View Blood Availability</a>
    <a href="purchase_blood.php"><i class="fas fa-cogs"></i> Blood Purchase & Bill</a>
    <a href="feedback.php"><i class="fas fa-comments"></i> Feedback</a>
    <a href="about.php"><i class="fas fa-info-circle"></i> About Us</a>
  </div>

  <!-- Logout Button -->
  <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>

  <!-- Container -->
  <div class="container">
    <p><h1>Welcome To The Dashboard , <?php echo $name; ?>!<br><br> Your Blood Group: <?php echo $blood_group; ?></h1></p>

    <div class="dashboard-grid">
      <div class="box">
        <i class="fas fa-tint"></i>
        <h3>Search Blood Donors</h3>
        <a href="search_donors.php">Go to Page</a>
      </div>
      <div class="box">
        <i class="fas fa-hand-holding-heart"></i>
        <h3>Request Blood</h3>
        <a href="request_blood.php">Go to Page</a>
      </div>
      <div class="box">
        <i class="fas fa-tint"></i>
        <h3>Blood Availability</h3>
        <a href="blood_availability.php">Go to Page</a>
      </div>
    </div>
  </div>

  <!-- Menu Toggle Script -->
  <script>
    function toggleMenu() {
      var menu = document.getElementById('menuBar');
      if (menu.style.left === '0px') {
        menu.style.left = '-250px';
      } else {
        menu.style.left = '0';
      }
    }
  </script>
</body>
</html>
