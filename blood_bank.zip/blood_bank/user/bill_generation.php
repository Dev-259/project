<?php
// Include the database connection file
include('../db_connect.php');

// Get current date and time
$current_datetime = date('Y-m-d H:i:s'); // 24-hour format with seconds

// Fetch blood stock details from the database
$sql = "SELECT * FROM blood_stock";
$result = $conn->query($sql);

// Store available blood groups and quantities in an array
$blood_stock = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $blood_stock[$row['blood_group']] = $row['quantity'];
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $blood_group = $_POST['blood_group'];
    $quantity = $_POST['quantity'];

    // Validate user input
    if (!array_key_exists($blood_group, $blood_stock)) {
        $error_message = "Invalid blood group.";
    } elseif ($blood_stock[$blood_group] < $quantity) {
        $error_message = "Insufficient blood stock. Only " . $blood_stock[$blood_group] . " units are available.";
    } else {
        // Calculate the total cost (assuming a fixed cost per unit)
        $cost_per_unit = 500; // Set the cost per unit of blood
        $total_cost = $quantity * $cost_per_unit;

        // Update the blood stock in the database
        $new_quantity = $blood_stock[$blood_group] - $quantity;
        $update_sql = "UPDATE blood_stock SET quantity = $new_quantity WHERE blood_group = '$blood_group'";
        $conn->query($update_sql);

        // Generate the bill with enhanced UI
        $bill = "
        <html>
        <head>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

            body {
                font-family: 'Poppins', sans-serif;
                margin: 0;
                padding: 0;
                background: url('../assets/bg3.jpg') no-repeat center center/cover;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
            }

            .overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
            }

            .bill-container {
                position: relative;
                width: 60%;
                background: rgba(255, 255, 255, 0.9);
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
                text-align: center;
                opacity: 0;
                animation: fadeIn 1s ease-in-out forwards;
                transform: scale(0.9);
                animation: fadeInScale 1s ease-in-out forwards;
            }

            @keyframes fadeInScale {
                from {
                    opacity: 0;
                    transform: scale(0.9);
                }
                to {
                    opacity: 1;
                    transform: scale(1);
                }
            }

            .bill-header h1 {
                margin: 0;
                font-size: 26px;
                font-weight: 600;
                color: #D32F2F;
                animation: slideIn 1s ease-in-out forwards;
            }

            .bill-header p {
                font-size: 14px;
                color: #555;
            }

            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .bill-details table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            }

            .bill-details th, .bill-details td {
                padding: 12px;
                text-align: center;
                border-bottom: 1px solid #ddd;
            }

            .bill-details th {
                background: #D32F2F;
                color: #fff;
            }

            .bill-details tr:hover {
                background: rgba(211, 47, 47, 0.1);
                transition: 0.3s;
            }

            .bill-footer {
                margin-top: 20px;
                font-size: 16px;
                color: #444;
                font-weight: 600;
                animation: fadeIn 1.5s ease-in-out forwards;
            }
        </style>
        </head>
        <body>
        <div class='overlay'></div>
        <div class='bill-container'>
            <div class='bill-header'>
                <h1>Blood Bank Purchase Bill</h1>
                <p>Date & Time: $current_datetime</p>
            </div>
            <div class='bill-details'>
                <table>
                    <tr>
                        <th>Blood Group</th>
                        <th>Quantity (Units)</th>
                        <th>Cost per Unit</th>
                        <th>Total Cost</th>
                    </tr>
                    <tr>
                        <td>$blood_group</td>
                        <td>$quantity</td>
                        <td>₹$cost_per_unit</td>
                        <td>₹$total_cost</td>
                    </tr>
                </table>
            </div>
            <div class='bill-footer'>
                <p>Thank you for your purchase! Stay healthy & save lives ❤️</p>
            </div>
        </div>
        </body>
        </html>";

        // Output the bill
        echo $bill;
    }
}
?>
