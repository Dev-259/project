<?php
    // Include database connection
    include('../db_connect.php');

    // Initialize variables
    $feedback_message = "";
    $name = "";
    $feedback = "";

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize user input
        $name = htmlspecialchars($_POST['name']);
        $feedback = htmlspecialchars($_POST['feedback']);
        
        // SQL query to insert feedback into database
        $sql = "INSERT INTO feedback (name, feedback) VALUES ('$name', '$feedback')";

        if (mysqli_query($conn, $sql)) {
            $feedback_message = "Thank you for your feedback!";
        } else {
            $feedback_message = "Error: " . mysqli_error($conn);
        }
    }

    // Fetch all feedbacks
    $result = mysqli_query($conn, "SELECT * FROM feedback ORDER BY submitted_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback - Blood Bank</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Body background and animation */
        body {
            background-image: url('../assets/bg3.jpg');
            background-size: cover;
            background-position: center center;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            animation: backgroundEffect 20s infinite alternate, zoomEffect 20s infinite alternate;
            margin: 0;
            padding: 0;
        }

        @keyframes backgroundEffect {
            0% {
                background-image: url('../assets/bg3.jpg');
                filter: brightness(0.8);
            }
            100% {
                background-image: url('../assets/bg4.jpg');
                filter: brightness(1);
            }
        }

        @keyframes zoomEffect {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
            }
        }

        /* Feedback container */
        .feedback-container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.7);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .feedback-container h2 {
            text-align: center;
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        /* Form input and textarea */
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus {
            border-color: #007BFF;
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Submit button */
        .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        /* Feedback message */
        .feedback-message {
            text-align: center;
            color: #28a745;
            font-size: 18px;
            margin-top: 20px;
        }

        /* List of feedback */
        .feedback-list {
            margin-top: 30px;
        }

        .feedback-list h3 {
            color: #333;
            text-align: center;
        }

        /* Individual feedback items */
        .feedback-item {
            background: rgba(255, 255, 255, 0.8);
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Back button */
        .back-btn {
            font-size: 18px;
            text-decoration: none;
            color: #007BFF;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .back-btn:hover {
            color: #0056b3;
        }

        .back-btn i {
            margin-right: 8px;
        }

    </style>
</head>
<body>

    <div class="feedback-container">
        <a href="home.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
        <h2>Submit Your Feedback</h2>

        <!-- Display feedback message if set -->
        <?php if ($feedback_message != ""): ?>
            <div class="feedback-message">
                <?php echo $feedback_message; ?>
            </div>
        <?php endif; ?>

        <!-- Feedback form -->
        <form action="feedback.php" method="post">
            <input type="text" name="name" placeholder="Your Name" value="<?php echo $name; ?>" required>
            <textarea name="feedback" placeholder="Your Feedback" rows="4" required><?php echo $feedback; ?></textarea>
            <button type="submit" class="submit-btn">Submit</button>
        </form>

        <!-- Display all feedback -->
        <div class="feedback-list">
            <h3>Recent Feedback</h3>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="feedback-item">
                    <strong><?php echo $row['name']; ?></strong> <br>
                    <small>Submitted on: <?php echo $row['submitted_at']; ?></small>
                    <p><?php echo $row['feedback']; ?></p>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

</body>
</html>
