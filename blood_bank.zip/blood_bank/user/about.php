<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Blood Bank</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('../assets/bg3.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            overflow-x: hidden;
        }

        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: rgba(255, 99, 71, 0.8);
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: rgba(255, 99, 71, 1);
        }

        .nav-links {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(0, 0, 0, 0.5);
            padding: 10px;
            border-radius: 5px;
            z-index: 10;
        }

        .nav-links button {
            color: white;
            background: none;
            border: none;
            font-size: 18px;
            font-weight: bold;
            margin: 0 10px;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .nav-links button:hover {
            color: #ff6347;
        }

        .section {
            padding: 40px;
            background: rgba(0, 0, 0, 0.6);
            margin: 30px;
            border-radius: 10px;
            animation: fadeIn 2s ease-out;
            transition: transform 0.3s ease;
            margin-top: 100px;
        }

        .section:hover {
            transform: scale(1.02);
        }

        .section h2 {
            font-size: 35px;
            margin-bottom: 20px;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            animation: slideUp 1s ease-out;
        }

        h2 i {
            margin-right: 10px;
            font-size: 1.5em;
            color: #ff6347;
        }

        .section p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .info-content {
            margin-top: 20px;
            font-size: 18px;
            line-height: 1.8;
        }

        .info-content ul {
            list-style-type: disc;
            padding-left: 20px;
        }

        .info-content li {
            margin: 10px 0;
            transition: color 0.3s ease;
        }

        .info-content li:hover {
            color: #ff6347;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

    <button class="back-btn" onclick="window.location.href='home.php';">&larr;</button>


    <div class="nav-links">
        <button onclick="scrollToSection('mission')">Mission</button>
        <button onclick="scrollToSection('vision')">Vision</button>
        <button onclick="scrollToSection('values')">Values</button>
        <button onclick="scrollToSection('team')">Team</button>
        <button onclick="scrollToSection('help')">How You Can Help</button>
    </div>

    <div id="mission" class="section">
        <h2><i class="fas fa-blood-drop"></i> Our Mission</h2>
        <div class="info-content">
            <p>Our mission is to provide accessible blood donations and save lives by connecting willing donors with those in need...</p>
            <ul>
                <li>Connect willing donors with recipients in need of blood.</li>
                <li>Build a strong network of blood donors.</li>
                <li>Encourage safe and easy donation processes.</li>
                <li>Promote awareness and education around blood donation.</li>
            </ul>
        </div>
    </div>

    <div id="vision" class="section">
        <h2><i class="fas fa-eye"></i> Our Vision</h2>
        <div class="info-content">
            <p>We envision a world where no one suffers due to a lack of blood...</p>
            <ul>
                <li>Provide accessible blood supplies worldwide.</li>
                <li>Ensure timely blood delivery during emergencies.</li>
                <li>Expand our donor network to reach every corner of society.</li>
                <li>Promote sustainable and safe donation practices.</li>
            </ul>
        </div>
    </div>

    <div id="values" class="section">
        <h2><i class="fas fa-heart"></i> Our Values</h2>
        <div class="info-content">
            <p>Our values guide everything we do. We operate with compassion, integrity, and efficiency...</p>
            <ul>
                <li><b>Compassion:</b> We care deeply about human life and its preservation.</li>
                <li><b>Integrity:</b> We operate with transparency and honesty in all our dealings.</li>
                <li><b>Community:</b> We believe in the strength of a connected community to help those in need.</li>
                <li><b>Efficiency:</b> We ensure that our blood delivery processes are as fast and safe as possible.</li>
            </ul>
        </div>
    </div>

    <div id="team" class="section">
        <h2><i class="fas fa-users"></i> Our Team</h2>
        <div class="info-content">
            <p>Our dedicated team works tirelessly to ensure that we are able to serve the community with blood donations...</p>
            <ul>
                <li><b>Doctors:</b> Experts in medical and blood transfusion processes.</li>
                <li><b>Volunteers:</b> Dedicated individuals assisting in donation drives.</li>
                <li><b>Management:</b> Overseeing operations to ensure smooth blood delivery.</li>
                <li><b>Logistics:</b> Ensuring safe transportation and storage of blood.</li>
            </ul>
        </div>
    </div>

    <div id="help" class="section">
        <h2><i class="fas fa-hands-helping"></i> How You Can Help</h2>
        <div class="info-content">
            <p>There are several ways in which you can make a difference in saving lives...</p>
            <ul>
                <li><b>Become a Regular Donor:</b> Give the gift of life through blood donations.</li>
                <li><b>Spread Awareness:</b> Educate your family and friends about the importance of blood donation.</li>
                <li><b>Volunteer:</b> Help in organizing donation drives and supporting the cause.</li>
                <li><b>Donate Funds:</b> Contribute to initiatives that promote safe blood donation.</li>
            </ul>
        </div>
    </div>

    <script>
        function scrollToSection(sectionId) {
            const section = document.getElementById(sectionId);
            section.scrollIntoView({
                behavior: 'smooth'
            });
        }
    </script>

</body>
</html>
