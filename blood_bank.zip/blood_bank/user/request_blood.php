<?php
// Include Database Connection
include('../db_connect.php');

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $blood_type = $_POST['blood_type'];
    $quantity = $_POST['quantity'];

    // Validate Quantity (Must be Positive)
    if ($quantity <= 0) {
        echo "<script>alert('Quantity must be a positive number!'); window.history.back();</script>";
        exit;
    }

    // Insert into Database
    $sql = "INSERT INTO blood_requests (blood_type, quantity, status) VALUES ('$blood_type', '$quantity', 'pending')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Blood request submitted successfully!'); window.location.href='request_blood.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Blood</title>
    <!-- Add Font Awesome CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('../assets/bg3.jpg'); /* Add your background image */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            flex-direction: column;
            overflow: hidden;
        }

        /* Back Link (Icon) with Animation */
        .back-link {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 24px;
            color: #0066cc; /* Change this to your desired color */
            text-decoration: none;
            transition: transform 0.3s ease, color 0.3s ease; /* Smooth transform and color transition */
        }

        .back-link:hover {
            color: #004d99; /* Hover color */
            transform: scale(1.1); /* Slight scale-up effect */
        }

        /* Container for the form with fade-in effect */
        .container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
            opacity: 0; /* Start with no opacity */
            animation: fadeIn 1.5s forwards; /* Fade-in animation */
        }

        h2 {
            margin-bottom: 20px;
            color: #d32f2f;
            transition: color 0.3s ease; /* Smooth color transition */
        }

        h2:hover {
            color: #b71c1c; /* Hover effect for heading */
        }

        /* Input, select, and button styling with subtle hover effect */
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: background-color 0.3s ease, box-shadow 0.3s ease; /* Smooth transition for input and button */
        }

        input:focus, select:focus, button:focus {
            background-color: #f7f7f7; /* Lighter background on focus */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow on focus */
        }

        button {
            background-color: #d32f2f;
            color: white;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.3s ease; /* Button background change and scale effect */
        }

        button:hover {
            background-color: #b71c1c;
            transform: scale(1.05); /* Slight scale-up effect on hover */
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Offline Icon Styling */
        .offline-icon {
            font-size: 24px;
            color: #d32f2f;
            margin-bottom: 20px;
            transition: transform 0.3s ease, color 0.3s ease; /* Smooth transition for offline icon */
        }

        .offline-icon:hover {
            transform: scale(1.1); /* Scale-up effect on hover */
            color: #b71c1c; /* Hover color */
        }
    </style>
</head>
<body>

    <!-- Back Link Icon -->
    <a href="home.php" class="back-link"><i class="fas fa-arrow-left"></i></a>

    <!-- Offline Icon (User is offline) -->
    <!-- Uncomment the line below if needed -->
    <!-- <p><i class="fas fa-user-slash offline-icon"></i> User is offline</p> -->

    <!-- Blood Request Form -->
    <div class="container">
        <h2>Request Blood</h2>
        <form action="" method="POST">
            <select name="blood_type" required>
                <option value="">Select Blood Type</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
            </select>

            <input type="number" name="quantity" placeholder="Quantity (units)" min="1" required>

            <button type="submit">Submit Request</button>
        </form>
    </div>

</body>
</html>
