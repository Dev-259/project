<?php
// Include database connection
include('../db_connect.php');

// Fetch available blood groups and quantities from the database
$query = "SELECT * FROM blood_stock WHERE status = 'Available'";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Purchase</title>

    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Internal CSS -->
    <style>
        body {
            background-image: url('../assets/bg3.jpg');
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
            animation: fadeIn 2s ease-in;
        }

        h1 {
            text-align: center;
            margin-top: 50px;
            font-size: 3em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .container {
            width: 50%;
            margin: auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .blood-group-select {
            margin: 20px 0;
            display: flex;
            justify-content: center;
        }

        select, input {
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 15px 32px;
            text-align: center;
            font-size: 1.5em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Styling for the back-to-dashboard icon */
        .back-to-dashboard {
            position: absolute;
            top: 10px;
            left: 10px;
            font-size: 2em;
            color: white;
            cursor: pointer;
            transition: color 0.3s;
        }

        .back-to-dashboard:hover {
            color: #4CAF50;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <!-- Back to Dashboard Icon -->
    <a href="home.php" class="back-to-dashboard">
        <i class="fas fa-arrow-left"></i>
    </a>

    <h1>Blood Purchase</h1>

    <div class="container">
        <form action="bill_generation.php" method="POST">
            <div class="blood-group-select">
                <label for="blood_group">Select Blood Group:</label>
                <select name="blood_group" id="blood_group" required>
                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                        <option value="<?php echo $row['blood_group']; ?>" data-quantity="<?php echo $row['quantity']; ?>">
                            <?php echo $row['blood_group']; ?> (<?php echo $row['quantity']; ?> units available)
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="blood-group-select">
                <label for="quantity">Quantity (in units):</label>
                <input type="number" name="quantity" id="quantity" required min="1" />
            </div>
            <button type="submit" name="submit">Generate Bill</button>
        </form>
    </div>

    <script>
        document.getElementById('blood_group').addEventListener('change', function() {
            var selectedOption = this.options[this.selectedIndex];
            var maxQuantity = selectedOption.getAttribute('data-quantity');
            document.getElementById('quantity').setAttribute('max', maxQuantity);
        });
    </script>
</body>
</html>
