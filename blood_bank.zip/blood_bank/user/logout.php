<?php
// Start the session
session_start();

// Redirect to login page if not logged in
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: ../auth/user_login.php");
    exit();
}

// Initialize the logout confirmation flag
$logout_confirmation = false;

// Check if the user clicked 'Yes' to logout
if (isset($_POST['logout']) && $_POST['logout'] == 'yes') {
    // Destroy all session variables
    session_unset();

    // Destroy the session
    session_destroy();

    // Redirect to the admin login page
    header("Location: ../auth/user_login.php");
    exit();
}

// Check if the user clicked 'No' to cancel logout
if (isset($_POST['logout']) && $_POST['logout'] == 'no') {
    // Stay on the current page and continue
    header("Location: home.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Logout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 50px;
            text-align: center;
        }

        .message {
            font-size: 18px;
            margin-bottom: 20px;
            color: #333;
        }

        .btn {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            margin: 5px;
            border: none;
            border-radius: 5px;
        }

        .btn-yes {
            background-color: #e74c3c;
            color: white;
        }

        .btn-no {
            background-color: #2ecc71;
            color: white;
        }
    </style>
</head>
<body>

    <div class="message">
        <p>Are you sure you want to log out?</p>
    </div>

    <!-- Form for handling logout confirmation -->
    <form method="post" action="">
        <input type="hidden" name="logout" value="yes">
        <button class="btn btn-yes" type="submit">Yes, Log Out</button>
    </form>

    <form method="post" action="">
        <input type="hidden" name="logout" value="no">
        <button class="btn btn-no" type="submit">No, Go Back</button>
    </form>

</body>
</html>
