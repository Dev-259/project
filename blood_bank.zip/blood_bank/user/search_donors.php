<?php
// Include database connection
include('../db_connect.php');

// Fetch blood groups from the database
$blood_query = "SELECT DISTINCT blood_group FROM donors";
$blood_result = mysqli_query($conn, $blood_query);

// Fetch unique locations from the database
$location_query = "SELECT DISTINCT location FROM donors";
$location_result = mysqli_query($conn, $location_query);

// Handle the form submission for searching donors
$blood_group = $location = '';
$donors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $blood_group = mysqli_real_escape_string($conn, $_POST['blood_group']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

    // SQL query to fetch donors based on the search criteria
    $sql = "SELECT * FROM donors WHERE blood_group = '$blood_group' AND location = '$location'";
    $donors = mysqli_query($conn, $sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Blood Donors</title>

    <!-- Internal CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('../assets/bg3.jpg');
            background-size: cover;
            background-position: center;
            color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        .container {
            background: rgba(0, 0, 0, 0.6);
            border-radius: 10px;
            padding: 30px;
            width: 80%;
            max-width: 800px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            animation: fadeIn 2s ease-out;
        }

        h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 20px;
            text-transform: uppercase;
            animation: slideIn 1s ease-out;
        }

        .form-group {
            margin-bottom: 20px;
            animation: fadeInUp 1s ease-out;
        }

        .form-group label {
            font-size: 1.1rem;
            margin-bottom: 8px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            border: 2px solid #fff;
            border-radius: 5px;
            background: #222;
            color: #fff;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            border-color: #ff6347;
            outline: none;
        }

        button {
            background: #ff6347;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #ff4500;
        }

        .dashboard-link {
            display: block;
            text-align: left;
            margin-bottom: 20px;
            font-size: 1.2rem;
            color: #ff6347;
            text-decoration: none;
            font-weight: bold;
        }

        .dashboard-link:hover {
            text-decoration: underline;
            color: #ff4500;
        }

        table {
            width: 100%;
            margin-top: 20px;
            animation: fadeInUp 1.5s ease-out;
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #fff;
        }

        table th {
            background-color: #333;
        }

        table tr:nth-child(even) {
            background-color: #444;
        }

        table tr:hover {
            background-color: #555;
            transition: background-color 0.3s;
        }

        .no-donor-message {
            text-align: center;
            font-size: 1.2rem;
            color: #ff6347;
            margin-top: 20px;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from { transform: translateX(-50%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

    </style>
</head>
<body>

    <div class="container">
        <!-- Dashboard Link (Text-Based) -->
        <a href="home.php" class="dashboard-link">&larr;	</a>

        <h2>Search Blood Donors</h2>

        <!-- Search form -->
        <form method="POST" action="search_donors.php">
            <div class="form-group">
                <label for="blood_group">Select Blood Group:</label>
                <select name="blood_group" id="blood_group" class="form-control">
                    <option value="">Select Blood Group</option>
                    <?php while($row = mysqli_fetch_assoc($blood_result)): ?>
                        <option value="<?= $row['blood_group']; ?>" <?= ($row['blood_group'] == $blood_group) ? 'selected' : ''; ?>>
                            <?= $row['blood_group']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="location">Select Location:</label>
                <select name="location" id="location" class="form-control">
                    <option value="">Select Location</option>
                    <?php while($row = mysqli_fetch_assoc($location_result)): ?>
                        <option value="<?= $row['location']; ?>" <?= ($row['location'] == $location) ? 'selected' : ''; ?>>
                            <?= $row['location']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <button type="submit">Search Donors</button>
        </form>

        <!-- Display search results -->
        <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
            <?php if(mysqli_num_rows($donors) > 0): ?>
                <h3>Found Donors:</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Blood Group</th>
                            <th>Location</th>
                            <th>Contact</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($donor = mysqli_fetch_assoc($donors)): ?>
                            <tr>
                                <td><?= $donor['name']; ?></td>
                                <td><?= $donor['blood_group']; ?></td>
                                <td><?= $donor['location']; ?></td>
                                <td><?= $donor['contact']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-donor-message">No donors found for the selected blood group and location.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

</body>
</html>
