<?php
include('../db_connect.php');

// Predefined blood groups
$blood_groups = ["A+", "B+", "AB+", "O+", "A-", "B-", "AB-", "O-"];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        $blood_group = $_POST['blood_group'];
        $quantity_to_add = $_POST['quantity'];
        $action = $_POST['action'];

        $query = "SELECT * FROM blood_stock WHERE blood_group = '$blood_group'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            if ($action == 'increase') {
                $new_quantity = $row['quantity'] + $quantity_to_add;
            } else {
                $new_quantity = max(0, $row['quantity'] - $quantity_to_add);
            }

            $update_query = "UPDATE blood_stock SET quantity = '$new_quantity' WHERE blood_group = '$blood_group'";
            $update_result = mysqli_query($conn, $update_query);

            echo $update_result ? "<script>alert('✅ Blood stock updated successfully!');</script>" 
                               : "<script>alert('❌ Failed to update blood stock.');</script>";
        } else {
            $insert_query = "INSERT INTO blood_stock (blood_group, quantity) VALUES ('$blood_group', '$quantity_to_add')";
            $insert_result = mysqli_query($conn, $insert_query);

            echo $insert_result ? "<script>alert('✅ Blood stock added successfully!');</script>" 
                               : "<script>alert('❌ Failed to add blood stock.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Blood Stock</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('../assets/bg6.jpg');
            background-size: cover;
            background-position: center;
            color: #fff;
            margin: 0;
            padding: 0;
            animation: fadeIn 1.5s ease-in-out, moveBackground 10s linear infinite; /* Combined fade-in and background movement animation */
        }

        /* Background image movement animation */
        @keyframes moveBackground {
            0% {
                background-position: 0 0;
            }
            50% {
                background-position: 50% 50%;
            }
            100% {
                background-position: 0 0;
            }
        }

        /* Header section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #000; /* Black Background */
            padding: 15px 20px;
            color: white;
            font-size: 22px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .header .dashboard-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 18px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .header .dashboard-btn:hover {
            background-color: #218838;
            transform: scale(1.1);
        }

        /* Container */
        .container {
            width: 70%;
            margin: 50px auto;
            background-color: rgba(0, 0, 0, 0.8);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            animation: slideIn 1s ease-out;
        }

        h2 {
            text-align: center;
            color: #ff5733;
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .form-group {
            margin: 20px 0;
        }

        label {
            font-weight: bold;
            font-size: 18px;
            color: #fff;
        }

        select, input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            transition: border 0.3s ease;
        }

        select:focus, input[type="number"]:focus {
            border: 2px solid #ff5733; /* Glowing effect on focus */
            box-shadow: 0 0 8px rgba(255, 87, 51, 0.6);
        }

        button {
            background-color: #ff5733;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #ff704d;
            transform: scale(1.1);
        }

        .blood-stock-table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
            background-color: #222;
            opacity: 0;
            animation: fadeInTable 1s ease-in-out forwards;
        }

        .blood-stock-table th, .blood-stock-table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #555;
            color: #fff;
        }

        .blood-stock-table th {
            background-color: #ff5733;
            color: #fff;
        }

        .blood-stock-table tr:hover {
            background-color: #444;
            cursor: pointer;
        }

        /* Animations */
        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            0% {
                transform: translateX(-100%);
            }
            100% {
                transform: translateX(0);
            }
        }

        @keyframes fadeInTable {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<!-- Header section -->
<div class="header">
    <div><a href="dashboard.php" class="dashboard-btn"><i class="fas fa-home"></i> </a>
    </div>
</div>

<div class="container">
    <h2><i class="fas fa-hand-holding-medical"></i> Manage Blood Stock</h2>
    
    <form action="" method="POST">
        <div class="form-group">
            <label for="blood_group"><i class="fas fa-vial"></i> Blood Group:</label>
            <select id="blood_group" name="blood_group" required>
                <?php
                    foreach ($blood_groups as $group) {
                        echo "<option value=\"$group\">$group</option>";
                    }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="quantity"><i class="fas fa-sort-numeric-up-alt"></i> Quantity (in units):</label>
            <input type="number" id="quantity" name="quantity" min="1" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-random"></i> Action:</label><br>
            <input type="radio" name="action" value="increase" required> Increase
            <input type="radio" name="action" value="decrease" required> Decrease
        </div>

        <button type="submit" name="add"><i class="fas fa-database"></i> Update Blood Stock</button>
    </form>

    <table class="blood-stock-table">
        <thead>
            <tr>
                <th><i class="fas fa-vial"></i> Blood Group</th>
                <th><i class="fas fa-tint"></i> Quantity</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT * FROM blood_stock";
            $result = mysqli_query($conn, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>{$row['blood_group']}</td><td>{$row['quantity']}</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
