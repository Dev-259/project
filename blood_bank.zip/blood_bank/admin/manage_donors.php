<?php
// Include the database connection
include('../db_connect.php');

// Fetch donor records from the database
$sql = "SELECT * FROM donors";
$result = mysqli_query($conn, $sql);

// Check if there are any donors
if (mysqli_num_rows($result) > 0) {
    $donors = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    $donors = [];
}

// Handle deletion of donor records
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM donors WHERE id = $delete_id";
    mysqli_query($conn, $delete_sql);
    header('Location: manage_donors.php'); // Redirect to reload page after deletion
}

// Handle adding a new donor
if (isset($_POST['add_donor'])) {
    $name = $_POST['name'];
    $blood_group = $_POST['blood_group'];
    $contact = $_POST['contact'];
    $age = $_POST['age'];
    $location = $_POST['location'];  // Add location field

    // Check if age is at least 18
    if ($age >= 18) {
        $add_sql = "INSERT INTO donors (name, blood_group, contact, age, location) 
                    VALUES ('$name', '$blood_group', '$contact', '$age', '$location')";
        mysqli_query($conn, $add_sql);
        header('Location: manage_donors.php'); // Redirect to reload page after addition
    } else {
        echo "<script>alert('Age must be 18 or older');</script>";
    }
}

// Handle editing donor details
if (isset($_POST['edit_donor'])) {
    $id = $_POST['donor_id'];
    $name = $_POST['name'];
    $blood_group = $_POST['blood_group'];
    $contact = $_POST['contact'];
    $age = $_POST['age'];
    $location = $_POST['location'];  // Add location field

    // Check if age is at least 18
    if ($age >= 18) {
        $edit_sql = "UPDATE donors SET name = '$name', blood_group = '$blood_group', contact = '$contact', age = '$age', location = '$location' WHERE id = $id";
        mysqli_query($conn, $edit_sql);
        header('Location: manage_donors.php'); // Redirect to reload page after edit
    } else {
        echo "<script>alert('Age must be 18 or older');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Donors - Blood Bank System</title>
    <!-- Link to Bootstrap (for styling) and Font Awesome (for icons) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('../assets/bg6.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #fff;
            height: 100vh;
            animation: fadeInBackground 3s ease-in-out;
        }

        @keyframes fadeInBackground {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .container {
            margin-top: 30px;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 10px;
            color: #ffcc00;
            animation: fadeInContainer 2s ease-in-out;
        }

        @keyframes fadeInContainer {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        .btn-custom {
            background-color: #28a745;
            color: white;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-custom:hover {
            background-color: #218838;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table th, .table td {
            text-align: center;
            color: #333;
            font-size: 1.1rem; /* Slightly bigger font for better readability */
        }

        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .table tbody tr:nth-child(odd) {
            background-color: #e9ecef;
        }

        .action-icons i {
            margin: 0 10px;
            cursor: pointer;
            transition: color 0.3s ease-in-out;
        }

        .action-icons i:hover {
            color: #dc3545;
        }

        .form-control {
            background-color: #f8f9fa;
        }

        .navbar {
            margin-bottom: 20px;
        }

        .navbar-nav .nav-item .nav-link {
            color: white;
        }

        .navbar-nav .nav-item .nav-link:hover {
            color: #007bff;
        }

        /* Attractiveness for text */
        h2 {
            font-size: 2.5rem;
            text-align: center;
            color: #f39c12;
            font-weight: bold;
            text-transform: uppercase;
        }

        .form-control {
            font-size: 1rem;
            padding: 12px;
            border-radius: 5px;
        }

        .table th, .table td {
            font-size: 1.2rem; /* Increase font size in table */
        }

        .btn-custom {
            font-size: 1.1rem;
        }

        /* Hover effect for table rows */
        .table tbody tr:hover {
            background-color: #dfe6e9;
            transform: scale(1.02);
            transition: transform 0.3s ease-in-out;
        }
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2 class="text-center mb-5">Manage Donors</h2>

        <!-- Form to Add New Donor -->
        <form method="POST" class="mb-4">
            <div class="form-row">
                <div class="col-md-3">
                    <input type="text" name="name" class="form-control" placeholder="Donor Name" required>
                </div>
                <div class="col-md-2">
                    <select name="blood_group" class="form-control" required>
                        <option value="">Select Blood Group</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="contact" class="form-control" placeholder="Contact Number" required>
                </div>
                <div class="col-md-2">
                    <input type="number" name="age" class="form-control" placeholder="Age" required>
                </div>
                <div class="col-md-2">
					<select name="location" class="form-control" required>
                        <option value="">Location</option>
                        <option value="Ahmedabad">Ahmedabad</option>
                        <option value="Vadodara">Vadodara</option>
                        <option value="Surat">Surat</option>
					</select>
                </div>
                <div class="col-md-1">
				<center>
                    <button type="submit" name="add_donor" class="btn btn-custom">
                        <i class="fas fa-plus"></i> Add
                    </button>
				</center>
                </div>
            </div>
        </form>

        <!-- Donor Table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Blood Group</th>
                    <th>Contact</th>
                    <th>Age</th>
                    <th>Location</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($donors as $donor): ?>
                    <tr>
                        <td><?php echo $donor['id']; ?></td>
                        <td><?php echo $donor['name']; ?></td>
                        <td><?php echo $donor['blood_group']; ?></td>
                        <td><?php echo $donor['contact']; ?></td>
                        <td><?php echo $donor['age']; ?></td>
                        <td><?php echo $donor['location']; ?></td>
                        <td class="action-icons">
                            <a href="#" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editDonorModal<?php echo $donor['id']; ?>"><i class="fas fa-edit"></i> Edit</a>
                            <a href="?delete_id=<?php echo $donor['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this donor?')"><i class="fas fa-trash"></i> Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal for Editing Donor -->
    <?php foreach ($donors as $donor): ?>
    <div class="modal fade" id="editDonorModal<?php echo $donor['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editDonorLabel<?php echo $donor['id']; ?>" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDonorLabel<?php echo $donor['id']; ?>">Edit Donor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <input type="hidden" name="donor_id" value="<?php echo $donor['id']; ?>">
                        <div class="form-row">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" value="<?php echo $donor['name']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <select name="blood_group" class="form-control" required>
                                    <option value="A+" <?php if ($donor['blood_group'] == 'A+') echo 'selected'; ?>>A+</option>
                                    <option value="A-" <?php if ($donor['blood_group'] == 'A-') echo 'selected'; ?>>A-</option>
                                    <option value="B+" <?php if ($donor['blood_group'] == 'B+') echo 'selected'; ?>>B+</option>
                                    <option value="B-" <?php if ($donor['blood_group'] == 'B-') echo 'selected'; ?>>B-</option>
                                    <option value="O+" <?php if ($donor['blood_group'] == 'O+') echo 'selected'; ?>>O+</option>
                                    <option value="O-" <?php if ($donor['blood_group'] == 'O-') echo 'selected'; ?>>O-</option>
                                    <option value="AB+" <?php if ($donor['blood_group'] == 'AB+') echo 'selected'; ?>>AB+</option>
                                    <option value="AB-" <?php if ($donor['blood_group'] == 'AB-') echo 'selected'; ?>>AB-</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="contact" class="form-control" value="<?php echo $donor['contact']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <input type="number" name="age" class="form-control" value="<?php echo $donor['age']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <select name="location" class="form-control" required>
									<option value="Ahmedabad"<?php if ($donor['location'] == 'Ahmedabad') echo 'selected'; ?>>Ahmedabad</option>
									<option value="Vadodara"<?php if ($donor['location'] == 'Vadodara') echo 'selected'; ?>>Vadodara</option>
									<option value="Surat"<?php if ($donor['location'] == 'Surat') echo 'selected'; ?>>Surat</option>
								</select>
                            </div>
                        </div>
                        <button type="submit" name="edit_donor" class="btn btn-custom mt-3">Update Donor</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- Include Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
