<?php
// Include database connection
include('../db_connect.php');

$message = "";
$selected_user = "";

// Handle form submission for update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $blood_group = $_POST['blood_group'];
    $status = $_POST['status'];

    // Use prepared statements for security
    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, phone=?, blood_group=?, status=? WHERE user_id=?");
    $stmt->bind_param("sssssi", $name, $email, $phone, $blood_group, $status, $user_id);
    $result = $stmt->execute();
    $stmt->close();

    if ($result) {
        $message = "<p style='color: lime; font-weight: bold;'>✔ User details updated successfully!</p>";
        $selected_user = $user_id;
    } else {
        $message = "<p style='color: red; font-weight: bold;'>❌ Error updating user details.</p>";
    }
}

// Fetch all users for dropdown
$query = "SELECT user_id, name FROM users";
$users_result = $conn->query($query);

// If edit button is clicked, get user details
if (isset($_POST['edit']) && isset($_POST['user_id'])) {
    $selected_user = $_POST['user_id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $selected_user);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../assets/bg3.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: auto;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(255, 255, 255, 0.2);
            margin-top: 50px;
            position: relative;
        }
        .dashboard-btn {
            position: absolute;
            top: 15px;
            left: 15px;
            text-decoration: none;
        }
        .dashboard-btn button {
            background: #D32F2F; /* Dark Red */
            padding: 10px 20px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
        }
        .dashboard-btn button:hover {
            background: #B71C1C; /* Darker Red */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            text-align: center;
        }
        input, select {
            padding: 10px;
            width: 95%;
            margin: 8px 0;
            border: none;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }
        select {
            color: black;
            background-color: white;
        }
        option {
            color: black;
            background-color: white;
        }
        button {
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            transition: 0.3s;
        }
        button:hover {
            background: #45a049;
        }
        .message {
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>User Management - Edit Details</h2>

    <!-- Back to Dashboard Button (Top-Right) -->
    <a href="dashboard.php" class="dashboard-btn">
        <button>
            &larr;
        </button>
    </a>

    <div class="message"><?= $message; ?></div>

    <!-- Dropdown for selecting a user to edit -->
    <form method="POST">
        <select name="user_id" required>
            <option value="">Select User</option>
            <?php while ($row = $users_result->fetch_assoc()) { ?>
                <option value="<?= $row['user_id']; ?>" <?= ($selected_user == $row['user_id']) ? 'selected' : ''; ?>><?= $row['name']; ?></option>
            <?php } ?>
        </select>
        <button type="submit" name="edit">Edit</button>
    </form>

    <?php if (isset($user)) { ?>
    <!-- User details form for updating -->
    <form method="POST">
        <input type="hidden" name="user_id" value="<?= $user['user_id']; ?>">
        <input type="text" name="name" value="<?= htmlspecialchars($user['name']); ?>" required placeholder="Full Name"><br>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required placeholder="Email"><br>
        <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']); ?>" required placeholder="Phone"><br>
        
        <select name="blood_group" required>
            <?php $blood_types = ['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-']; ?>
            <?php foreach ($blood_types as $type) { ?>
                <option value="<?= $type; ?>" <?= ($user['blood_group'] == $type) ? 'selected' : ''; ?>><?= $type; ?></option>
            <?php } ?>
        </select><br>

        <select name="status">
            <option value="active" <?= ($user['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
            <option value="inactive" <?= ($user['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
        </select><br>
        
        <button type="submit" name="update">Update</button>
    </form>
    <?php } ?>
</div>

</body>
</html>
