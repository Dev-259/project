<?php
// Include database connection
include('../db_connect.php');

// Query to get all pending blood requests
$query_pending = "
    SELECT 
        r.request_id, r.blood_type, r.quantity, r.status, r.timestamp, 
        u.name AS user_name, u.email, u.phone
    FROM blood_requests r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.status = 'pending'
";

// Query to get all approved blood requests
$query_approved = "
    SELECT 
        r.request_id, r.blood_type, r.quantity, r.status, r.timestamp, 
        u.name AS user_name, u.email, u.phone
    FROM blood_requests r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.status = 'approved'
";

// Query to get all rejected blood requests
$query_rejected = "
    SELECT 
        r.request_id, r.blood_type, r.quantity, r.status, r.timestamp, 
        u.name AS user_name, u.email, u.phone
    FROM blood_requests r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.status = 'rejected'
";

$result_pending = mysqli_query($conn, $query_pending);
$result_approved = mysqli_query($conn, $query_approved);
$result_rejected = mysqli_query($conn, $query_rejected);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Blood Requests</title>
    
    <!-- Internal CSS -->
    <style>
        body {
            background-image: url('../assets/bg3.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            animation: fadeIn 1s ease-in-out;
        }

        /* Fade in effect for page */
        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        /* Table Styles */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: rgba(0, 0, 0, 0.7);
        }

        th, td {
            padding: 15px;
            text-align: left;
            color: #f1f1f1;
        }

        th {
            background-color: #4e73df; /* Blue color for header */
            font-size: 18px;
            animation: slideIn 0.5s ease-in-out;
            color: #ffffff; /* White text on blue header */
        }

        /* Animation for text to slide in */
        @keyframes slideIn {
            0% {
                transform: translateX(-100%);
                opacity: 0;
            }
            100% {
                transform: translateX(0);
                opacity: 1;
            }
        }

        tr:nth-child(even) {
            background-color: #333;
        }

        tr:nth-child(odd) {
            background-color: #444;
        }

        button {
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        .approve-btn {
            background-color: #28a745;
        }

        .approve-btn:hover {
            background-color: #218838;
        }

        .reject-btn {
            background-color: #dc3545;
        }

        .reject-btn:hover {
            background-color: #c82333;
        }

        .no-actions {
            background-color: #6c757d;
            cursor: not-allowed;
            box-shadow: none;
        }

        footer {
            text-align: center;
            padding: 15px;
            background-color: #2f2f2f;
            margin-top: 20px;
        }

        .button-back {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            display: inline-block;
        }

        .button-back:hover {
            background-color: #0056b3;
        }

        /* Header Styles */
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px;
            background-color: #333;
            animation: slideIn 0.5s ease-in-out;
        }

        header h1 {
            font-size: 24px;
            background: linear-gradient(45deg, #ff6347, #ff1493); /* Gradient color */
            -webkit-background-clip: text;
            color: transparent;
            animation: fadeInUp 1s ease-out;
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .button-dashboard {
            font-size: 24px;
            color: white;
            text-decoration: none;
        }

        .button-dashboard:hover {
            color: #0056b3;
            transform: scale(1.1);
        }

        /* Font Awesome */
        .fa {
            font-size: 24px;
        }

        /* Title styles for Pending, Approved, and Rejected Blood Requests */
        .requests-title {
            background: linear-gradient(45deg, #ffcc00, #ff6347); /* Gradient color */
            color: transparent;
            -webkit-background-clip: text;
            font-size: 26px;
            font-weight: bold;
            text-align: center;
            animation: fadeInUp 1s ease-out;
            text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.2); /* Subtle shadow for depth */
        }
    </style>
</head>
<body>

<!-- Header with "Dashboard" link and "Manage Requests" title -->
<header>
    <a href="dashboard.php" class="button-dashboard">
        <i class="fa fa-tachometer-alt"></i> <!-- Icon for Dashboard -->
    </a>
    <h1>Manage Requests</h1>
</header>

<!-- Blood Requests Section -->
<div class="card">
    <h2 class="requests-title">Pending, Approved, and Rejected Blood Requests</h2> <!-- Changed text color to gradient with shadow -->
    <table>
        <tr>
            <th>User Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Blood Type</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>

        <?php
        // Pending Requests
        while ($row = mysqli_fetch_assoc($result_pending)) {
            echo "<tr>
                    <td>{$row['user_name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['blood_type']}</td>
                    <td>{$row['quantity']}</td>
                    <td>{$row['status']}</td>
                    <td>
                        <button class='approve-btn'>
                            Approve
                        </button>
                        <button class='reject-btn'>
                            Reject
                        </button>
                    </td>
                </tr>";
        }

        // Approved Requests
        while ($row = mysqli_fetch_assoc($result_approved)) {
            echo "<tr>
                    <td>{$row['user_name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['blood_type']}</td>
                    <td>{$row['quantity']}</td>
                    <td>{$row['status']}</td>
                    <td>
                        <button class='no-actions' disabled>
                            No Actions Allowed
                        </button>
                    </td>
                </tr>";
        }

        // Rejected Requests
        while ($row = mysqli_fetch_assoc($result_rejected)) {
            echo "<tr>
                    <td>{$row['user_name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['blood_type']}</td>
                    <td>{$row['quantity']}</td>
                    <td>{$row['status']}</td>
                    <td>
                        <button class='no-actions' disabled>
                            No Actions Allowed
                        </button>
                    </td>
                </tr>";
        }
        ?>

    </table>
</div>

<!-- Footer (Optional) -->
<!-- <footer>
    <p>&copy; 2025 Blood Bank Management System</p>
</footer> -->

<!-- Internal JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
<script>
    // Confirm actions before approval or rejection
    document.querySelectorAll('.approve-btn').forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Are you sure you want to approve this request?')) {
                // Implement approval logic (e.g., update database)
                alert('Blood request approved!');
            }
        });
    });

    document.querySelectorAll('.reject-btn').forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Are you sure you want to reject this request?')) {
                // Implement rejection logic (e.g., update database)
                alert('Blood request rejected!');
            }
        });
    });
</script>

</body>
</html>
