<?php
// Include the database connection file
include('../db_connect.php');

// Query to get blood requests data
$sql_blood_requests = "SELECT blood_type, quantity, status, timestamp FROM blood_requests";
$result_blood_requests = mysqli_query($conn, $sql_blood_requests);

// Query to get blood stock data
$sql_blood_stock = "SELECT * FROM blood_stock";
$result_blood_stock = mysqli_query($conn, $sql_blood_stock);

// Query to get donor data
$sql_donors = "SELECT name, blood_group, contact, age, location FROM donors";
$result_donors = mysqli_query($conn, $sql_donors);

// Export to CSV functionality
if(isset($_POST['export'])) {
    // Check if any checkbox is selected
    if(isset($_POST['blood_requests'])) {
        exportToCSV($result_blood_requests, 'blood_requests.csv');
    }

    if(isset($_POST['blood_stock'])) {
        exportToCSV($result_blood_stock, 'blood_stock.csv');
    }

    if(isset($_POST['donors'])) {
        exportToCSV($result_donors, 'donors.csv');
    }

    // If all checkboxes are unchecked
    if(!isset($_POST['blood_requests']) && !isset($_POST['blood_stock']) && !isset($_POST['donors'])) {
        echo "<script>alert('Please select at least one option to export.');</script>";
    }
}

function exportToCSV($data, $filename) {
    $output = fopen('php://output', 'w');
    // Output headers for the CSV
    $headers = array();
    if($row = mysqli_fetch_assoc($data)) {
        // Write the headers (columns)
        $headers = array_keys($row);
        fputcsv($output, $headers);
        // Write the data rows
        fputcsv($output, $row);
        // Output remaining rows
        while($row = mysqli_fetch_assoc($data)) {
            fputcsv($output, $row);
        }
    }

    // Set the header for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    fclose($output);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Report</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #ff7e5f, #feb47b);
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            display: flex;
            align-items: center;
            justify-content: center;
            background: #333;
            color: white;
            padding: 15px;
            font-size: 22px;
            position: relative;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .back-btn {
            position: absolute;
            left: 15px;
            background: #ff5733;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            transition: background 0.3s ease-in-out;
        }
        .back-btn:hover {
            background: #c70039;
        }
        nav {
            background: #444;
            display: flex;
            justify-content: center;
            padding: 10px;
        }
        nav a {
            color: white;
            padding: 12px 20px;
            margin: 0 10px;
            text-decoration: none;
            font-size: 18px;
            transition: all 0.3s ease-in-out;
            border-radius: 5px;
        }
        nav a:hover {
            background: #ff5733;
            transform: scale(1.1);
        }
        nav a.active {
            background: #ffcc29;
            color: black;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            background: white;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }
        th {
            background: #ff5733;
            color: white;
            text-transform: uppercase;
        }
        tr:hover {
            background: #f9f9f9;
            transform: scale(1.02);
        }
        .table-container {
            background: rgba(255, 255, 255, 0.8);
            margin: 20px auto;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
        }
        h2 {
            text-align: center;
            color: #333;
            font-size: 24px;
            margin-bottom: 15px;
            padding-top: 20px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }
        /* Export section layout */
        .export-container {
            background: #333;
            color: white;
            padding: 30px;
            margin-top: 40px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 80%;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
        .export-container form {
            display: inline-block;
            width: 100%;
            max-width: 400px;
        }
        .export-container label {
            font-size: 18px;
            display: block;
            margin-bottom: 10px;
        }
        .export-container input[type="checkbox"] {
            margin-right: 10px;
            transform: scale(1.2);
        }
        .export-btn {
            background: #ff5733;
            color: white;
            padding: 15px 25px;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s ease-in-out;
            border: none;
        }
        .export-btn:hover {
            background: #c70039;
        }
    </style>
</head>
<body>

<header>
    <a href="dashboard.php" class="back-btn">&larr;</a>
    Blood Bank Report
</header>

<nav>
    <a href="#blood_requests" class="active">Blood Requests</a>
    <a href="#blood_stock">Blood Stock</a>
    <a href="#donors">Donors</a>
</nav>

<!-- Content Section -->
<div class="content-section">
    <h2 id="blood_requests">Blood Requests</h2>
    <div class="table-container">
        <table>
            <tr>
                <th>Blood Type</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Timestamp</th>
            </tr>
            <?php
            while($row = mysqli_fetch_assoc($result_blood_requests)) {
                echo "<tr>
                        <td>{$row['blood_type']}</td>
                        <td>{$row['quantity']}</td>
                        <td>{$row['status']}</td>
                        <td>{$row['timestamp']}</td>
                    </tr>";
            }
            ?>
        </table>
    </div>

    <h2 id="blood_stock">Blood Stock</h2>
    <div class="table-container">
        <table>
            <tr>
                <th>Blood Group</th>
                <th>Quantity</th>
                <th>Status</th>
            </tr>
            <?php
            while($row = mysqli_fetch_assoc($result_blood_stock)) {
                echo "<tr>
                        <td>{$row['blood_group']}</td>
                        <td>{$row['quantity']}</td>
                        <td>{$row['status']}</td>
                    </tr>";
            }
            ?>
        </table>
    </div>

    <h2 id="donors">Donors</h2>
    <div class="table-container">
        <table>
            <tr>
                <th>Name</th>
                <th>Blood Group</th>
                <th>Contact</th>
                <th>Age</th>
                <th>Location</th>
            </tr>
            <?php
            while($row = mysqli_fetch_assoc($result_donors)) {
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['blood_group']}</td>
                        <td>{$row['contact']}</td>
                        <td>{$row['age']}</td>
                        <td>{$row['location']}</td>
                    </tr>";
            }
            ?>
        </table>
    </div>
</div>

<!-- Export Section at the bottom -->
<div class="export-container">
    <h2>Export Data</h2>
    <form method="POST" action="">
        <label><input type="checkbox" name="blood_requests"> Export Blood Requests</label><br>
        <label><input type="checkbox" name="blood_stock"> Export Blood Stock</label><br>
        <label><input type="checkbox" name="donors"> Export Donors</label><br><br>
        <button type="submit" name="export" class="export-btn">Export Selected Data</button>
    </form>
</div>

</body>
</html>

<?php
mysqli_close($conn);
?>
