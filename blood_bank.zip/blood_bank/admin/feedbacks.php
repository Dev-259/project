<?php
// Include database connection
include('../db_connect.php');

// Handle delete request
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $sql_delete = "DELETE FROM feedback WHERE id = $delete_id";
    if (mysqli_query($conn, $sql_delete)) {
        echo "<script>alert('Feedback deleted successfully'); window.location.href='feedbacks.php';</script>";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

// Handle edit request
if (isset($_POST['edit_feedback'])) {
    $feedback_id = $_POST['feedback_id'];
    $new_feedback = $_POST['feedback'];
    $sql_edit = "UPDATE feedback SET feedback = '$new_feedback' WHERE id = $feedback_id";
    if (mysqli_query($conn, $sql_edit)) {
        echo "<script>alert('Feedback updated successfully'); window.location.href='feedbacks.php';</script>";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Fetch feedback from the database
$sql = "SELECT * FROM feedback ORDER BY submitted_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Management</title>
    <style>
        /* General styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: url('../assets/bg3.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }

        header {
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        header a {
            text-decoration: none;
            color: white;
            font-size: 20px;
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .content {
            width: 80%;
            margin: 30px auto;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            animation: fadeIn 1s ease-in-out;
            color: #333; /* Text color for better contrast */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            animation: slideIn 0.5s ease-in-out;
            color: #333; /* Text color for table content */
        }

        th, td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease-in-out;
        }

        .action-buttons a {
            text-decoration: none;
            color: white;
            background-color: #28a745;
            padding: 5px 10px;
            border-radius: 5px;
            margin: 5px;
            transition: background-color 0.3s ease-in-out;
        }

        .action-buttons a:hover {
            background-color: #218838;
        }

        .edit-form {
            display: inline-block;
            width: 100%;
            margin-top: 10px;
            padding: 20px;
            background-color: #f4f4f9;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            opacity: 0;
            transform: translateY(50px);
            animation: fadeInUp 1s forwards;
        }

        .edit-form textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            resize: vertical;
        }

        .edit-form button {
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .edit-form button:hover {
            background-color: #0056b3;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                transform: translateX(-100%);
            }
            to {
                transform: translateX(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<header>
    <a href="dashboard.php">&#8592; </a>
    <h1>Feedback Management</h1>
</header>

<div class="content">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Feedback</th>
                <th>Submitted At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['feedback']}</td>
                        <td>{$row['submitted_at']}</td>
                        <td class='action-buttons'>
                            <a href='#' onclick='editFeedback({$row['id']}, \"{$row['feedback']}\")'>Edit</a>
                            <a href='feedbacks.php?delete={$row['id']}'>Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No feedback available</td></tr>";
            }
            ?>
        </tbody>
    </table>
    
    <!-- Edit Form (Initially Hidden) -->
    <div id="edit-form" class="edit-form" style="display:none;">
        <h2>Edit Feedback</h2>
        <form method="POST">
            <input type="hidden" name="feedback_id" id="feedback_id">
            <textarea name="feedback" id="feedback_text" required></textarea><br>
            <button type="submit" name="edit_feedback">Update Feedback</button>
        </form>
    </div>
</div>

<script>
    function editFeedback(id, feedback) {
        // Show the edit form and fill it with the existing feedback
        document.getElementById("edit-form").style.display = "block";
        document.getElementById("feedback_id").value = id;
        document.getElementById("feedback_text").value = feedback;
    }
</script>

</body>
</html>

<?php
// Close the connection
mysqli_close($conn);
?>
