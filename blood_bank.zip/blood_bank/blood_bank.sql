-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 27, 2025 at 03:18 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin12');

-- --------------------------------------------------------

--
-- Table structure for table `blood_requests`
--

DROP TABLE IF EXISTS `blood_requests`;
CREATE TABLE IF NOT EXISTS `blood_requests` (
  `request_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `blood_type` varchar(10) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blood_requests`
--

INSERT INTO `blood_requests` (`request_id`, `user_id`, `blood_type`, `quantity`, `status`, `timestamp`) VALUES
(13, NULL, 'B+', 5, 'pending', '2025-02-26 09:19:31'),
(12, 101, 'B+', 3, 'pending', '2025-02-26 07:50:31'),
(9, 109, 'O-', 3, 'rejected', '2025-02-23 12:29:01'),
(8, 108, 'AB-', 1, 'rejected', '2025-02-23 12:29:01'),
(7, 107, 'B-', 1, 'approved', '2025-02-23 12:29:01'),
(6, 106, 'A-', 2, 'approved', '2025-02-23 12:29:01'),
(5, 105, 'O+', 1, 'approved', '2025-02-23 12:29:01'),
(4, 104, 'AB+', 1, 'pending', '2025-02-23 12:29:01'),
(3, 103, 'B+', 3, 'pending', '2025-02-23 12:29:01'),
(2, 102, 'O-', 1, 'pending', '2025-02-23 12:29:01'),
(1, 101, 'A+', 2, 'pending', '2025-02-23 12:29:01'),
(14, NULL, 'B+', 6, 'pending', '2025-02-26 09:33:15'),
(15, NULL, 'B+', 3, 'pending', '2025-02-26 12:25:51');

-- --------------------------------------------------------

--
-- Table structure for table `blood_stock`
--

DROP TABLE IF EXISTS `blood_stock`;
CREATE TABLE IF NOT EXISTS `blood_stock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blood_group` varchar(10) NOT NULL,
  `quantity` int NOT NULL,
  `status` varchar(20) DEFAULT 'Available',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blood_stock`
--

INSERT INTO `blood_stock` (`id`, `blood_group`, `quantity`, `status`) VALUES
(24, 'AB-', 15, 'Available'),
(23, 'AB+', 9, 'Available'),
(22, 'O-', 0, 'Available'),
(21, 'O+', 13, 'Available'),
(20, 'B-', 0, 'Available'),
(19, 'B+', 2, 'Available'),
(18, 'A-', 3, 'Available'),
(17, 'A+', 1, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

DROP TABLE IF EXISTS `donors`;
CREATE TABLE IF NOT EXISTS `donors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `age` int DEFAULT NULL,
  `location` enum('Ahmedabad','Surat','Vadodara','') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `name`, `blood_group`, `contact`, `created_at`, `age`, `location`) VALUES
(3, 'Dev Rana', 'A+', '09328806392', '2025-02-22 15:28:00', 19, 'Ahmedabad'),
(4, 'Chavda Riyaz', 'B+', '09328806392', '2025-02-22 15:28:19', 21, 'Surat'),
(5, 'Rahul Patel', 'O+', '09123456789', '2025-02-26 07:31:33', 25, 'Ahmedabad'),
(6, 'Sneha Shah', 'A-', '09234567890', '2025-02-26 07:31:33', 28, 'Surat'),
(7, 'Vikram Mehta', 'B-', '09345678901', '2025-02-26 07:31:33', 30, 'Vadodara'),
(8, 'Pooja Desai', 'AB+', '09456789012', '2025-02-26 07:31:33', 22, 'Ahmedabad'),
(9, 'Amit Trivedi', 'O-', '09567890123', '2025-02-26 07:31:33', 26, 'Surat'),
(10, 'Komal Joshi', 'A+', '09678901234', '2025-02-26 07:31:33', 24, 'Vadodara'),
(11, 'Rohan Singh', 'B+', '09789012345', '2025-02-26 07:31:33', 29, 'Ahmedabad'),
(12, 'Meera Patel', 'AB-', '09890123456', '2025-02-26 07:31:33', 21, 'Surat'),
(13, 'Kunal Thakkar', 'O+', '09901234567', '2025-02-26 07:31:33', 27, 'Vadodara'),
(14, 'Payal Shah', 'A-', '09012345678', '2025-02-26 07:31:33', 23, 'Ahmedabad'),
(15, 'Dhruv Bhatt', 'B-', '09123456780', '2025-02-26 07:31:33', 31, 'Surat'),
(16, 'Simran Gohil', 'AB+', '09234567812', '2025-02-26 07:31:33', 20, 'Vadodara'),
(17, 'Jay Parmar', 'O-', '09345678923', '2025-02-26 07:31:33', 22, 'Ahmedabad'),
(18, 'Kishan Rana', 'A+', '09456789034', '2025-02-26 07:31:33', 29, 'Surat'),
(19, 'Neha Vyas', 'B+', '09567890145', '2025-02-26 07:31:33', 26, 'Vadodara');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `feedback` text NOT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `feedback`, `submitted_at`) VALUES
(1, 'Dev Rana', 'it was good purchasing from here', '2025-02-26 14:33:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `blood_group` varchar(5) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `phone`, `blood_group`, `password`, `status`, `created_at`) VALUES
(102, 'Jane Smith', 'jane@example.com', '1234567891', 'A+', 'password123', 'active', '2025-02-23 12:29:12'),
(101, 'John Doe', 'john@example.com', '1234567890', 'B+', 'password123', 'active', '2025-02-23 12:29:12'),
(103, 'Mark Johnson', 'mark@example.com', '1234567892', 'A+', 'password123', 'active', '2025-02-23 12:29:12'),
(104, 'Emily Davis', 'emily@example.com', '1234567893', 'AB+', 'password123', 'active', '2025-02-23 12:29:12'),
(105, 'Paul Walker', 'paul@example.com', '1234567894', 'A-', 'password123', 'active', '2025-02-23 12:29:12'),
(106, 'Nina Turner', 'nina@example.com', '1234567895', 'B-', 'password123', 'active', '2025-02-23 12:29:12'),
(107, 'Robert King', 'robert@example.com', '1234567896', 'O-', 'password123', 'active', '2025-02-23 12:29:12'),
(108, 'Alice Green', 'alice@example.com', '1234567897', 'AB-', 'password123', 'active', '2025-02-23 12:29:12'),
(109, 'George Brown', 'george@example.com', '1234567898', 'A+', 'password123', 'active', '2025-02-23 12:29:12'),
(110, 'Dev Rana', 'devr07j@gmail.com', '08849630131', 'A+', 'dev07', 'active', '2025-02-23 17:21:37');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
